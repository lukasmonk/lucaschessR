
rm -f units/*.*

for n in {1..8}
do
  fpc -Mobjfpc -Sh -Fu.. -FUunits make$n.pas
  sleep 1
  ./make$n
done
