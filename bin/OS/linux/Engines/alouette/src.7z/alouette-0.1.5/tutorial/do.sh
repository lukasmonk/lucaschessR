
rm -f *.out
rm -f units/*.*

for f in *.pas
do
  fpc -Mobjfpc -Sh -Fu.. -FUunits $f | tee fpc.out
  if [ -f ${f%.pas} ]
  then
    ./${f%.pas} > ${f%.pas}.out
  fi
done
